package com.sam.edison2;

/**
 * Created by Sam on 3/15/2016.
 */
/**
 * Simple point
 */
public class Point {

    public float x = 0;
    public float y = 0;

    public Point(float x, float y) {
        this.x = x;
        this.y = y;
    }
}
