# IoT_Challenge
Taller Vertical 2016
